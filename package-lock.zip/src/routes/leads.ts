import { Router } from "express";
import cookie from "cookie";
import { pool } from "../db";
import { findSessionBySid, touchSession } from "../services/sessionService";

const router = Router();
console.log("[leads.ts] LOADED FROM", __filename);

// ──────────────────────────────────────────────────────────────────────────────
// Auth middleware
// ──────────────────────────────────────────────────────────────────────────────
async function requireSession(req: any, res: any, next: any) {
  try {
    const cookiesObj = cookie.parse(req.headers.cookie || "");
    const sid = cookiesObj.sid || cookiesObj.ssr_sid; // accept either
    if (!sid) return res.status(401).json({ error: "unauthenticated" });

    const sess = await findSessionBySid(sid);
    if (!sess) return res.status(401).json({ error: "invalid_session" });

    req.session = { sid: sess.sid, user_id: sess.user_id, tenant_id: sess.tenant_id };
    touchSession(sid).catch(() => {});
    next();
  } catch (err) {
    next(err);
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/leads → list leads for this tenant
// ──────────────────────────────────────────────────────────────────────────────
router.get("/leads", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const result = await cx.query(
      `
      select
        id,
        tenant_id,
        company_id,
        owner_id,
        pipeline_id,
        stage_id,
        name,
        primary_email as email,
        coalesce(primary_phone, primary_phone_e164) as phone,
        primary_phone_e164,
        source_id,
        status,
        stage,
        estimated_value,
        probability,
        tags,
        meta,
        created_by,
        created_at,
        updated_at
      from public.lead
      where tenant_id = $1
      order by created_at desc
      `,
      [tenantId]
    );

    res.json({ leads: result.rows });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/leads/:id → lead detail + notes + tasks
// ──────────────────────────────────────────────────────────────────────────────
router.get("/leads/:id", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;

  if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const leadQ = await cx.query(
      `
      select
        id, tenant_id, company_id, owner_id, pipeline_id, stage_id,
        name,
        primary_email as email,
        coalesce(primary_phone, primary_phone_e164) as phone,
        primary_phone_e164,
        source_id, status, stage,
        estimated_value, probability, tags, meta,
        created_by, created_at, updated_at
      from public.lead
      where id = $1 and tenant_id = $2
      limit 1
      `,
      [leadId, tenantId]
    );
    if (leadQ.rowCount === 0) return res.status(404).json({ error: "not_found" });

    const notesQ = await cx.query(
      `
      select id, lead_id, body, author_id, created_at
      from public.lead_note
      where lead_id = $1 and tenant_id = $2
      order by created_at desc
      `,
      [leadId, tenantId]
    );

    const tasksQ = await cx.query(
      `
      select id, lead_id, title, status, due_date, assigned_to, created_by, created_at, completed_at
      from public.lead_task
      where lead_id = $1 and tenant_id = $2
      order by created_at desc
      `,
      [leadId, tenantId]
    );

    res.json({ lead: leadQ.rows[0], notes: notesQ.rows, tasks: tasksQ.rows });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/leads/:id/history → stage change history (safe if table missing)
// ──────────────────────────────────────────────────────────────────────────────
router.get("/leads/:id/history", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    try {
      const q = await cx.query(
        `
        select
          h.id,
          h.lead_id,
          h.from_stage,
          h.to_stage,
          h.from_stage_id,
          h.to_stage_id,
          h.changed_by,
          u.name as changed_by_name,
          h.created_at
        from public.lead_stage_history h
        left join public.app_user u
          on u.id = h.changed_by and u.tenant_id = h.tenant_id
        where h.tenant_id = $1 and h.lead_id = $2
        order by h.created_at desc
        `,
        [tenantId, leadId]
      );
      return res.json({ history: q.rows });
    } catch (e: any) {
      if (e?.code === "42P01") return res.json({ history: [] }); // table missing
      throw e;
    }
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
/** POST /api/leads → create lead (supports meta/value/prob/tags/etc.) */
// ──────────────────────────────────────────────────────────────────────────────
router.post("/leads", requireSession, async (req: any, res: any, next: any) => {
  const {
    lead_name, name, title,
    email,
    phone, phone_e164,
    assigned_user_id,
    company_id,
    estimated_value,
    probability,
    tags,
    source_id,
    pipeline_id,
    stage_id,
    meta, // JSONB
  } = req.body || {};

  try {
    const finalName: string = String(lead_name || name || title || "").trim();
    if (!finalName) return res.status(400).json({ error: "lead_name_required" });

    const tenantId = req.session?.tenant_id as string | null;
    const userId   = req.session?.user_id as string | null;
    if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

    const estVal =
      estimated_value === undefined || estimated_value === null || estimated_value === ""
        ? null
        : Number(estimated_value);
    const prob =
      probability === undefined || probability === null || probability === ""
        ? null
        : Math.min(100, Math.max(0, Number(probability)));
    const tagArr: string[] = Array.isArray(tags) ? tags : [];
    const safeMeta = meta && typeof meta === "object" ? meta : {};

    const cx = await pool.connect();
    try {
      await cx.query("BEGIN");
      await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
      await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

      // Resolve company_id
      let finalCompanyId: string | null = null;
      if (company_id) {
        const ok = await cx.query(
          `select 1 from public.company where id = $1 and tenant_id = $2 limit 1`,
          [company_id, tenantId]
        );
        if (ok.rowCount === 0) return res.status(400).json({ error: "invalid_company_id" });
        finalCompanyId = company_id;
      } else {
        const u = await cx.query(
          `select company_id from public.app_user where id = $1 and tenant_id = $2`,
          [userId, tenantId]
        );
        if (u.rows[0]?.company_id) {
          finalCompanyId = u.rows[0].company_id as string;
        } else {
          const companies = await cx.query(
            `select id from public.company where tenant_id = $1`,
            [tenantId]
          );
          if (companies.rowCount === 1) {
            finalCompanyId = companies.rows[0].id as string;
          } else {
            await cx.query("ROLLBACK");
            return res.status(400).json({
              error: "company_required",
              companies: companies.rows.map((r: any) => r.id),
            });
          }
        }
      }

      await cx.query(`select set_config('app.company_id', $1::text, true)`, [String(finalCompanyId)]);

      const ins = await cx.query(
        `
        insert into public.lead
          (tenant_id, company_id, owner_id, pipeline_id, stage_id,
           name, primary_email, primary_phone, primary_phone_e164,
           source_id, status,
           estimated_value, probability, tags, meta,
           created_by)
        values
          ($1,        $2,         $3,       $4,         $5,
           $6,        $7,          $8,       $9,
           $10,       $11,
           $12,       $13,         $14,      $15,
           $16)
        returning
          id, tenant_id, company_id, owner_id, pipeline_id, stage_id,
          name, primary_email as email,
          coalesce(primary_phone, primary_phone_e164) as phone,
          primary_phone_e164,
          source_id, status, stage,
          estimated_value, probability, tags, meta,
          created_by, created_at, updated_at
        `,
        [
          tenantId,
          finalCompanyId,
          assigned_user_id ?? null,
          pipeline_id ?? null,
          stage_id ?? null,

          finalName,
          email ?? null,
          null,
          (phone_e164 || phone) ?? null,

          source_id ?? null,
          "new",

          estVal,
          prob,
          tagArr,
          safeMeta,

          userId,
        ]
      );

      await cx.query("COMMIT");
      res.status(201).json({ lead: ins.rows[0] });
    } catch (err: any) {
      try { await cx.query("ROLLBACK"); } catch {}
      if (err?.code === "23503") {
        return res.status(400).json({ error: "foreign_key_violation", detail: err?.detail });
      }
      next(err);
    } finally {
      cx.release();
    }
  } catch (err) {
    next(err);
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// PATCH /api/leads/:id → update core fields + shallow-merge meta
// ──────────────────────────────────────────────────────────────────────────────
router.patch("/leads/:id", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

  const {
    name,
    email,
    phone,
    phone_e164,
    status,
    stage,
    owner_id,
    company_id,
    pipeline_id,
    stage_id,
    estimated_value,
    probability,
    tags,
    meta, // shallow merge into JSONB
  } = req.body || {};
  const tagArr = Array.isArray(tags) ? tags : undefined;

  const cx = await pool.connect();
  try {
    await cx.query("BEGIN");
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const upd = await cx.query(
      `
      update public.lead
      set
        name = coalesce($2, name),
        primary_email = coalesce($3, primary_email),
        primary_phone_e164 = coalesce($4, primary_phone_e164),
        status = coalesce($5, status),
        stage = coalesce($6, stage),
        owner_id = coalesce($7, owner_id),
        company_id = coalesce($8, company_id),
        pipeline_id = coalesce($9, pipeline_id),
        stage_id = coalesce($10, stage_id),
        estimated_value = coalesce($11, estimated_value),
        probability = coalesce($12, probability),
        tags = coalesce($13, tags),
        meta = case
          when $14::jsonb is null then meta
          else jsonb_strip_nulls(coalesce(meta, '{}'::jsonb) || $14::jsonb)
        end,
        updated_at = now()
      where id = $1 and tenant_id = $15
      returning
        id, tenant_id, company_id, owner_id, pipeline_id, stage_id,
        name, primary_email as email,
        coalesce(primary_phone, primary_phone_e164) as phone,
        primary_phone_e164,
        source_id, status, stage,
        estimated_value, probability, tags, meta,
        created_by, created_at, updated_at
      `,
      [
        leadId,
        name ?? null,
        email ?? null,
        (phone_e164 ?? phone) ?? null,
        status ?? null,
        stage ?? null,
        owner_id ?? null,
        company_id ?? null,
        pipeline_id ?? null,
        stage_id ?? null,
        estimated_value !== undefined ? Number(estimated_value) : null,
        probability !== undefined ? Math.min(100, Math.max(0, Number(probability))) : null,
        tagArr ?? null,
        meta ?? null,
        tenantId,
      ]
    );

    await cx.query("COMMIT");
    if (upd.rowCount === 0) return res.status(404).json({ error: "not_found" });
    res.json({ lead: upd.rows[0] });
  } catch (err) {
    try { await cx.query("ROLLBACK"); } catch {}
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// POST /api/leads/:id/move → move to a stage by id or by name (free text OK)
// Works whether pipeline_stage has tenant_id or not; also works if table missing
// Body: { stage_id?: string, stage?: string }
// ──────────────────────────────────────────────────────────────────────────────
// POST /api/leads/:id/move  — accepts { stage_id?: string, stage?: string }
router.post("/leads/:id/move", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  const { stage_id, stage } = req.body || {};
  if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });
  if (!stage_id && (!stage || !String(stage).trim())) {
    return res.status(400).json({ error: "stage_or_stage_id_required" });
  }

  const looksLikeUuid = (s: any) =>
    typeof s === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);

  const cx = await pool.connect();
  try {
    await cx.query("BEGIN");
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    let newStageName:  string | null = null;
    let newStageId:    string | null = null;
    let newPipelineId: string | null = null;

    async function probePipelineStageByIdOrName(key: string) {
      // Detect available columns once
      const cols = await cx.query(
        `select column_name from information_schema.columns
          where table_schema='public' and table_name='pipeline_stage'`
      );
      const set = new Set(cols.rows.map((r: any) => r.column_name as string));
      const hasTenant = set.has("tenant_id");

      // 1) try by id (SAFE: compare id::text to avoid UUID cast on $1)
      {
        const where = hasTenant
          ? "where id::text = $1 and tenant_id = $2"
          : "where id::text = $1";
        const params: any[] = hasTenant ? [key, tenantId] : [key];
        const q = await cx.query(
          `select id, name, pipeline_id from public.pipeline_stage ${where} limit 1`,
          params
        );
        if (q.rowCount > 0) return q.rows[0];
      }

      // 2) try by name (case-insensitive)
      {
        const where = hasTenant
          ? "where lower(name) = lower($1) and tenant_id = $2"
          : "where lower(name) = lower($1)";
        const params: any[] = hasTenant ? [key, tenantId] : [key];
        const q = await cx.query(
          `select id, name, pipeline_id from public.pipeline_stage ${where} limit 1`,
          params
        );
        if (q.rowCount > 0) return q.rows[0];
      }

      return null;
    }

    async function resolveAsName(nameVal: string) {
      const name = String(nameVal).trim();
      // Try to resolve against pipeline_stage if the table exists; else accept free text
      try {
        const rec = await probePipelineStageByIdOrName(name);
        if (rec) {
          newStageId = rec.id;
          newStageName = rec.name;
          newPipelineId = rec.pipeline_id ?? null;
        } else {
          newStageId = null;
          newStageName = name;
        }
      } catch (e: any) {
        if (e?.code === "42P01") { // pipeline_stage doesn’t exist
          newStageId = null;
          newStageName = name;
        } else {
          throw e;
        }
      }
    }

    if (stage && String(stage).trim()) {
      await resolveAsName(stage);
    } else if (stage_id) {
      // If it's not a UUID, treat it as a name immediately.
      if (!looksLikeUuid(stage_id)) {
        await resolveAsName(stage_id);
      } else {
        // It's a UUID-looking token → still use id::text to avoid casts
        try {
          const rec = await probePipelineStageByIdOrName(stage_id);
          if (rec) {
            newStageId = rec.id;
            newStageName = rec.name;
            newPipelineId = rec.pipeline_id ?? null;
          } else {
            // UUID-looking but not found → fallback to name
            await resolveAsName(stage_id);
          }
        } catch (e: any) {
          if (e?.code === "42P01") {
            // no table → free text
            newStageId = null;
            newStageName = String(stage_id);
          } else {
            throw e;
          }
        }
      }
    }

    if (!newStageName) return res.status(400).json({ error: "unable_to_resolve_stage" });

    const upd = await cx.query(
      `
      update public.lead
         set stage      = $3,
             stage_id   = $4,
             pipeline_id= coalesce($5, pipeline_id),
             updated_at = now()
       where id = $1 and tenant_id = $2
       returning id, stage, stage_id, pipeline_id, updated_at
      `,
      [leadId, tenantId, newStageName, newStageId, newPipelineId]
    );

    await cx.query("COMMIT");
    if (upd.rowCount === 0) return res.status(404).json({ error: "not_found" });
    res.json({ lead: upd.rows[0] });
  } catch (err) {
    try { await cx.query("ROLLBACK"); } catch {}
    next(err);
  } finally {
    cx.release();
  }
});


// ──────────────────────────────────────────────────────────────────────────────
// POST /api/leads/:id/notes → add a note
// ──────────────────────────────────────────────────────────────────────────────
router.post("/leads/:id/notes", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  const { body } = req.body || {};
  if (!body || !String(body).trim()) return res.status(400).json({ error: "note_body_required" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const ins = await cx.query(
      `
      insert into public.lead_note (tenant_id, lead_id, body, author_id)
      values ($1, $2, $3, $4)
      returning id, lead_id, body, author_id, created_at
      `,
      [tenantId, leadId, String(body), userId]
    );

    res.status(201).json({ note: ins.rows[0] });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// POST /api/leads/:id/tasks → add a task (status=open)
// ──────────────────────────────────────────────────────────────────────────────
router.post("/leads/:id/tasks", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  const { title, due_date } = req.body || {};
  if (!title || !String(title).trim()) return res.status(400).json({ error: "task_title_required" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const ins = await cx.query(
      `
      insert into public.lead_task (tenant_id, lead_id, title, status, due_date, created_by)
      values ($1, $2, $3, 'open', $4, $5)
      returning id, lead_id, title, status, due_date, assigned_to, created_by, created_at, completed_at
      `,
      [tenantId, leadId, String(title), due_date || null, userId]
    );

    res.status(201).json({ task: ins.rows[0] });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// PATCH /api/leads/:id/tasks/:taskId → update task status
// ──────────────────────────────────────────────────────────────────────────────
router.patch("/leads/:id/tasks/:taskId", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  const taskId   = req.params.taskId as string;
  const { status } = req.body || {};
  if (!["open", "done", "canceled"].includes(status)) return res.status(400).json({ error: "invalid_status" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const upd = await cx.query(
      `
      update public.lead_task
      set status = $3,
          completed_at = case
            when $3 = 'done' then now()
            when $3 = 'open' then null
            else completed_at
          end
      where id = $2 and lead_id = $1 and tenant_id = $4
      returning id, lead_id, title, status, due_date, assigned_to, created_by, created_at, completed_at
      `,
      [leadId, taskId, status, tenantId]
    );

    if (upd.rowCount === 0) return res.status(404).json({ error: "not_found" });
    res.json({ task: upd.rows[0] });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// POST /api/leads/:id/close → mark won/lost + record reason/time in meta.close
// ──────────────────────────────────────────────────────────────────────────────
router.post("/leads/:id/close", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  const { outcome, reason } = req.body || {};
  if (!["won", "lost"].includes(outcome)) return res.status(400).json({ error: "invalid_outcome" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const upd = await cx.query(
      `
      update public.lead
      set status = $3::text,
          stage  = $3::text,
          meta = jsonb_strip_nulls(
            coalesce(meta, '{}'::jsonb) ||
            jsonb_build_object('close', jsonb_build_object(
              'outcome', $3::text, 'reason', $4::text, 'at', now()
            ))
          ),
          updated_at = now()
      where id = $2 and tenant_id = $1
      returning id, status, stage, meta, updated_at
      `,
      [tenantId, leadId, outcome, reason || null]
    );

    if (upd.rowCount === 0) return res.status(404).json({ error: "not_found" });
    res.json({ lead: upd.rows[0] });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// POST /api/leads/:id/reopen → clear close info & set back to open
// ──────────────────────────────────────────────────────────────────────────────
router.post("/leads/:id/reopen", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  const leadId   = req.params.id as string;
  if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    const upd = await cx.query(
      `
      update public.lead
         set status = 'open',
             stage  = 'New',
             updated_at = now(),
             meta = jsonb_strip_nulls(
               (coalesce(meta, '{}'::jsonb) - 'close') ||
               jsonb_build_object('reopen', jsonb_build_object('by', $3, 'at', now()))
             )
       where id = $1 and tenant_id = $2
       returning id, status, stage, updated_at, meta
      `,
      [leadId, tenantId, userId]
    );

    if (upd.rowCount === 0) return res.status(404).json({ error: "not_found" });
    res.json({ lead: upd.rows[0] });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/stages → unified list (pipeline_stage → lead_stage → defaults)
// ──────────────────────────────────────────────────────────────────────────────
// ──────────────────────────────────────────────────────────────────────────────
// GET /api/stages → unified list (pipeline_stage → lead_stage → defaults)
// Adapts to missing columns like probability/order_index/is_won/is_lost
// ──────────────────────────────────────────────────────────────────────────────
// ──────────────────────────────────────────────────────────────────────────────
// GET /api/stages → unified list (pipeline_stage → lead_stage → defaults)
// Handles missing tenant_id/order_index/probability/is_won/is_lost gracefully
// ──────────────────────────────────────────────────────────────────────────────
router.get("/stages", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id as string | null;
  if (!tenantId || !userId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    // 1) Prefer pipeline_stage if present
    try {
      // Try with tenant_id + order_index
      try {
        const q = await cx.query(
          `
          select id, name, pipeline_id, order_index
            from public.pipeline_stage
           where tenant_id = $1
           order by coalesce(order_index, 9999), name
          `,
          [tenantId]
        );
        if (q.rowCount > 0) return res.json({ stages: q.rows });
      } catch (e: any) {
        if (e?.code === "42703") {
          // Either tenant_id or order_index missing — probe which one(s) and retry.
          // Probe columns on pipeline_stage:
          const cols = await cx.query(
            `
            select column_name
              from information_schema.columns
             where table_schema='public' and table_name='pipeline_stage'
            `
          );
          const set = new Set(cols.rows.map((r: any) => r.column_name as string));
          const hasTenant = set.has("tenant_id");
          const hasOrder  = set.has("order_index");

          const where = hasTenant ? "where tenant_id = $1" : "";
          const params: any[] = hasTenant ? [tenantId] : [];
          const selectOrderIndex = hasOrder ? "order_index" : "null::int as order_index";
          const orderBy = hasOrder ? "coalesce(order_index, 9999), name" : "name";

          const q2 = await cx.query(
            `
            select id, name, pipeline_id, ${selectOrderIndex}
              from public.pipeline_stage
              ${where}
             order by ${orderBy}
            `,
            params
          );
          if (q2.rowCount > 0) return res.json({ stages: q2.rows });
        } else {
          throw e;
        }
      }
    } catch (e: any) {
      if (e?.code !== "42P01") console.warn("[/stages] pipeline_stage unavailable:", e?.code || e);
      // fall through to lead_stage / defaults
    }

    // 2) Fall back to lead_stage (detect available columns dynamically)
    try {
      const colsQ = await cx.query(
        `
        select column_name
          from information_schema.columns
         where table_schema = 'public'
           and table_name   = 'lead_stage'
        `
      );
      const colset = new Set<string>(colsQ.rows.map((r: any) => String(r.column_name)));

      const hasProb  = colset.has("probability");
      const hasWon   = colset.has("is_won");
      const hasLost  = colset.has("is_lost");
      const hasOrder = colset.has("order_index");
      const hasCA    = colset.has("created_at");

      const selectList = [
        "id",
        "name",
        hasProb  ? "probability"                : "null::int  as probability",
        hasWon   ? "is_won"                     : "false      as is_won",
        hasLost  ? "is_lost"                    : "false      as is_lost",
        hasOrder ? "order_index"                : "null::int  as order_index",
        "null::uuid as pipeline_id",
        hasCA    ? "created_at"                 : "now()      as created_at",
      ].join(", ");

      const orderBy = hasOrder ? "coalesce(order_index, 999999), name" : "name";

      const s = await cx.query(
        `
        select ${selectList}
          from public.lead_stage
         where tenant_id = $1
         order by ${orderBy}
        `,
        [tenantId]
      );
      if (s.rowCount > 0) return res.json({ stages: s.rows });
    } catch (e: any) {
      if (e?.code !== "42P01") throw e; // table missing → fallback below
    }

    // 3) Final fallback: distinct lead.stage + defaults
    const defaults = ["New", "Qualified", "Proposal", "Negotiation", "Won", "Lost"];
    const distinct = await cx.query(
      `select distinct stage as name
         from public.lead
        where tenant_id = $1 and stage is not null
        order by name`,
      [tenantId]
    );
    const names = Array.from(new Set<string>([...defaults, ...distinct.rows.map(r => String(r.name))]));
    const stages = names.map((name, i) => ({
      id: name,
      name,
      pipeline_id: null,
      order_index: i,
    }));
    res.json({ stages });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// GET /api/scheduler/leads → calendar feed for leads in a date range
// Query: date_from=YYYY-MM-DD, date_to=YYYY-MM-DD, page?, pageSize?
// Uses l.next_action_at (rename if your column differs)
// ──────────────────────────────────────────────────────────────────────────────
// ──────────────────────────────────────────────────────────────────────────────
// GET /api/scheduler/leads → calendar feed for the UI
// Auto-detects where the date lives:
//   1) prefer public.lead_task.due_date (joined to lead)
//   2) else use a date column on public.lead: follow_up_at | next_contact_at | next_follow_up_at
// Query: date_from=YYYY-MM-DD, date_to=YYYY-MM-DD, page?, pageSize?
// ──────────────────────────────────────────────────────────────────────────────
// ──────────────────────────────────────────────────────────────────────────────
// GET /api/scheduler/leads?date_from=YYYY-MM-DD&date_to=YYYY-MM-DD&page=1&pageSize=1000
// Returns normalized calendar "events" from lead.meta.follow_up_date and lead_task.due_date
// date_to is EXCLUSIVE
// ──────────────────────────────────────────────────────────────────────────────
// ──────────────────────────────────────────────────────────────────────────────
// GET /api/scheduler/leads?date_from=YYYY-MM-DD&date_to=YYYY-MM-DD&page=1&pageSize=1000
// Returns follow-ups (lead.meta.follow_up_date) + open tasks (lead_task.due_date)
// ──────────────────────────────────────────────────────────────────────────────
router.get("/scheduler/leads", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id as string | null;
  const userId   = req.session?.user_id   as string | null;

  const { date_from, date_to } = req.query || {};
  const page      = Math.max(1, Number(req.query.page || 1));
  const pageSize  = Math.min(1000, Math.max(1, Number(req.query.pageSize || 1000)));

  if (!tenantId || !userId) return res.status(401).json({ error: "unauthenticated" });
  if (!date_from || !date_to) return res.status(400).json({ error: "date_from_and_date_to_required" });

  // sanitize to dates only
  const from = String(date_from).slice(0, 10);
  const to   = String(date_to).slice(0, 10);

  const cx = await pool.connect();
  try {
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [tenantId]);
    await cx.query(`select set_config('app.user_id',   $1::text, true)`, [userId]);

    // 1) Lead follow-ups from JSONB meta.follow_up_date
    // NOTE: your table has no column next_action_at, so do NOT reference it.
    const followUps = await cx.query(
      `
      select
        l.id                         as lead_id,
        l.name                       as lead_name,
        (l.meta->>'follow_up_date')::date as event_date,
        'lead_follow_up'             as kind,
        null::uuid                   as task_id,
        l.status                     as status
      from public.lead l
      where l.tenant_id = $1
        and (l.meta->>'follow_up_date') is not null
        and (l.meta->>'follow_up_date')::date between $2::date and $3::date
      `,
      [tenantId, from, to]
    );

    // 2) Open lead tasks by due_date
    const tasks = await cx.query(
      `
      select
        t.lead_id                    as lead_id,
        l.name                       as lead_name,
        t.due_date::date             as event_date,
        'lead_task'                  as kind,
        t.id                         as task_id,
        t.status                     as status
      from public.lead_task t
      join public.lead l
        on l.id = t.lead_id
       and l.tenant_id = t.tenant_id
      where t.tenant_id = $1
        and t.status in ('open')               -- adjust if you want 'done' too
        and t.due_date between $2::date and $3::date
      `,
      [tenantId, from, to]
    );

    // Combine + sort + paginate
    const all = [...followUps.rows, ...tasks.rows]
      .filter(r => r.event_date)                // safety
      .sort((a, b) => (a.event_date as any) - (b.event_date as any));

    const total = all.length;
    const start = (page - 1) * pageSize;
    const events = all.slice(start, start + pageSize);

    // Be generous with field names the UI might expect:
    res.json({
      events,          // primary
      items: events,   // alias (just in case UI maps to items)
      total,
      page,
      pageSize,
      range: { from, to }
    });
  } catch (err) {
    next(err);
  } finally {
    cx.release();
  }
});





export default router;
