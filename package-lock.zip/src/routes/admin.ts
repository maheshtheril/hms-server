// server/src/routes/admin.ts
import { Router } from "express";
import { q } from "../db";

const router = Router();

// ───────────────────────────────────────────────
// GET /api/admin/users
// Paginated list of users, with optional search + active filter
// ───────────────────────────────────────────────
router.get("/users", async (req, res, next) => {
  try {
    const page = Math.max(parseInt(String(req.query.page || "1")), 1);
    const pageSize = Math.min(Math.max(parseInt(String(req.query.pageSize || "20")), 1), 100);
    const offset = (page - 1) * pageSize;
    const search = String(req.query.search || "").trim();
    const active = String(req.query.active ?? "").trim(); // "" means no filter

    const params: any[] = [];
    let where = "WHERE 1=1";

    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      where += ` AND (LOWER(name) LIKE $${params.length} OR LOWER(email) LIKE $${params.length})`;
    }
    if (active !== "") {
      params.push(active === "true");
      where += ` AND is_active = $${params.length}`;
    }

    // Count total
    const { rows: countRows } = await q(
      `SELECT COUNT(*)::int AS total FROM app_user ${where}`,
      params
    );
    const total = countRows[0]?.total ?? 0;

    // Add pagination params
    params.push(pageSize);
    params.push(offset);

    // Fetch paginated items
    const { rows: items } = await q(
      `SELECT id, email, name, is_active, is_admin, tenant_id, company_id, created_at
         FROM app_user
         ${where}
         ORDER BY created_at DESC NULLS LAST
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    res.json({ items, page, pageSize, total });
  } catch (err) {
    next(err);
  }
});

// ───────────────────────────────────────────────
// Canary endpoint: prove the admin router is mounted
// GET /api/admin/__health
// ───────────────────────────────────────────────
router.get("/__health", (_req, res) => {
  res.json({ ok: true, where: "admin router file" });
});

// ───────────────────────────────────────────────
// GET /api/admin/roles
// For now: stub response (replace with real DB query later)
// ───────────────────────────────────────────────


// ───────────────────────────────────────────────
// GET /api/admin/permissions
// For now: stub response (replace with real DB query later)
// ───────────────────────────────────────────────

// ───────────────────────────────────────────────
// Default export
// ───────────────────────────────────────────────
export default router;
