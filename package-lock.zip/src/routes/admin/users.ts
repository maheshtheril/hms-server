import { Router } from "express";
import { pool } from "../../db";
// import requireSession from "../../middleware/requireSession"; // if you have it

const router = Router();

// ──────────────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────────────
function isUuid(v: string) {
  return /^[0-9a-fA-F-]{36}$/.test(v);
}

// If you use RLS with app.tenant_id, call this before queries
async function setTenant(req: any) {
  const tenantId = req.session?.tenant_id || req.headers["x-tenant-id"] || null;
  if (tenantId) {
    await pool.query(`select set_config('app.tenant_id', $1, true)`, [String(tenantId)]);
  }
}

/** GET /api/admin/users?page&pageSize&search&role&active&sort&dir */
router.get("/", /* requireSession, */ async (req, res, next) => {
  try {
    await setTenant(req);

    const { page = "1", pageSize = "20", search = "" } = req.query as any;
    const limit = Math.max(1, parseInt(pageSize, 10));
    const offset = (Math.max(1, parseInt(page, 10)) - 1) * limit;

    const q = `
      SELECT id, email, name,
             COALESCE(is_admin,false)            AS is_admin,
             COALESCE(is_platform_admin,false)   AS is_platform_admin,
             COALESCE(is_tenant_admin,false)     AS is_tenant_admin,
             COALESCE(is_active,true)            AS is_active,
             created_at,
             COUNT(*) OVER()                     AS __total
      FROM public.app_user
      WHERE ($1 = '' OR email ILIKE '%'||$1||'%' OR COALESCE(name,'') ILIKE '%'||$1||'%')
      ORDER BY (name IS NULL), name ASC, email ASC
      LIMIT $2 OFFSET $3
    `;

    const { rows } = await pool.query(q, [search, limit, offset]);
    const total = rows[0]?.__total ? Number(rows[0].__total) : 0;

    res.json({
      items: rows.map(({ __total, ...rest }) => rest),
      meta: { page: Number(page), pageSize: limit, total },
    });
  } catch (e) {
    next(e);
  }
});

/** GET /api/admin/users/:id */
router.get("/:id", /* requireSession, */ async (req, res, next) => {
  try {
    await setTenant(req);

    const { id } = req.params;
    if (!isUuid(id)) {
      return res.status(400).json({ error: "bad_request", message: "id must be a UUID" });
    }

    const q = `
      SELECT id, email, name,
             COALESCE(is_admin,false)            AS is_admin,
             COALESCE(is_platform_admin,false)   AS is_platform_admin,
             COALESCE(is_tenant_admin,false)     AS is_tenant_admin,
             COALESCE(is_active,true)            AS is_active,
             created_at
      FROM public.app_user
      WHERE id = $1::uuid
      LIMIT 1
    `;
    const { rows } = await pool.query(q, [id]);
    if (rows.length === 0) return res.status(404).json({ error: "not_found" });
    res.json(rows[0]);
  } catch (e) {
    next(e);
  }
});

/** PATCH /api/admin/users/:id */
router.patch("/:id", /* requireSession, */ async (req, res, next) => {
  try {
    await setTenant(req);

    const { id } = req.params;
    if (!isUuid(id)) {
      return res.status(400).json({ error: "bad_request", message: "id must be a UUID" });
    }

    const { email, name, is_active, is_admin, is_tenant_admin, is_platform_admin } = req.body || {};

    const q = `
      UPDATE public.app_user SET
        email              = COALESCE($2, email),
        name               = COALESCE($3, name),
        is_active          = COALESCE($4, is_active),
        is_admin           = COALESCE($5, is_admin),
        is_tenant_admin    = COALESCE($6, is_tenant_admin),
        is_platform_admin  = COALESCE($7, is_platform_admin)
      WHERE id = $1::uuid
      RETURNING id, email, name,
        COALESCE(is_admin,false)            AS is_admin,
        COALESCE(is_platform_admin,false)   AS is_platform_admin,
        COALESCE(is_tenant_admin,false)     AS is_tenant_admin,
        COALESCE(is_active,true)            AS is_active,
        created_at
    `;
    const params = [
      id,
      email ?? null,
      name ?? null,
      typeof is_active === "boolean" ? is_active : null,
      typeof is_admin === "boolean" ? is_admin : null,
      typeof is_tenant_admin === "boolean" ? is_tenant_admin : null,
      typeof is_platform_admin === "boolean" ? is_platform_admin : null,
    ];

    const { rows } = await pool.query(q, params);
    if (rows.length === 0) return res.status(404).json({ error: "not_found" });
    res.json(rows[0]);
  } catch (e) {
    next(e);
  }
});

/** POST /api/admin/users/:id/resend-invite */
router.post("/:id/resend-invite", /* requireSession, */ async (req, res, next) => {
  try {
    await setTenant(req);

    const { id } = req.params;
    if (!isUuid(id)) {
      return res.status(400).json({ error: "bad_request", message: "id must be a UUID" });
    }

    // TODO: implement actual email/invite send
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

export default router;
