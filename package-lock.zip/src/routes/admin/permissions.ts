// server/src/routes/admin/permissions.ts
import { Router } from "express";
import { pool } from "../../db";

const router = Router();

const CATALOG: Record<string, string> = {
  "platform_admin": "Platform Admin",
  "tenant_admin": "Tenant Admin",
  "users.read": "Read Users",
  "users.write": "Manage Users",
  "roles.read": "Read Roles",
  "roles.write": "Manage Roles",
  "leads.read": "Read Leads",
  "leads.write": "Manage Leads",
};

const humanize = (code: string) =>
  code.replace(/[_\.]/g, " ").replace(/\b\w/g, s => s.toUpperCase());

router.get("/", async (_req, res, next) => {
  try {
    const used = await pool.query(`
      WITH all_codes AS (
        SELECT DISTINCT unnest(permissions) AS code
        FROM public.role
        WHERE permissions IS NOT NULL AND array_length(permissions,1) > 0
      )
      SELECT code FROM all_codes ORDER BY code ASC
    `);

    const out: Array<{ code: string; name: string }> = [];
    const seen = new Set<string>();

    for (const [code, name] of Object.entries(CATALOG)) {
      if (!seen.has(code)) { seen.add(code); out.push({ code, name }); }
    }
    for (const r of used.rows) {
      const code = String(r.code);
      if (!seen.has(code)) { seen.add(code); out.push({ code, name: humanize(code) }); }
    }

    out.sort((a, b) => a.name.localeCompare(b.name));
    res.json({ items: out });
  } catch (e) { next(e); }
});

export default router;
