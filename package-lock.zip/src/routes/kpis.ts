// server/src/routes/kpis.ts
import { Router } from "express";
import cookie from "cookie";
import { pool } from "../db";
import { findSessionBySid, touchSession } from "../services/sessionService";

const router = Router();

async function requireSession(req: any, res: any, next: any) {
  try {
    const cookies = cookie.parse(req.headers.cookie || "");
    const sid = cookies.sid;
    if (!sid) return res.status(401).json({ error: "unauthenticated" });

    const sess = await findSessionBySid(sid);
    if (!sess) return res.status(401).json({ error: "invalid_session" });

    req.session = { sid: sess.sid, user_id: sess.user_id, tenant_id: sess.tenant_id };
    touchSession(sid).catch(() => {});
    next();
  } catch (e) { next(e); }
}

router.get("/kpis", requireSession, async (req: any, res: any, next: any) => {
  const tenantId = req.session?.tenant_id;
  if (!tenantId) return res.status(400).json({ error: "tenant_id_missing_in_session" });

  const cx = await pool.connect();
  try {
    await cx.query("BEGIN");

    // set RLS context for this connection
    await cx.query(`select set_config('app.tenant_id', $1::text, true)`, [String(tenantId)]);

    // "Open" = not closed (tweak to your statuses)
    const { rows: [{ open_leads_count }] } = await cx.query(`
      select count(*)::int as open_leads_count
      from public.lead
      where tenant_id = $1
        and coalesce(status, 'new') <> 'closed'
    `, [tenantId]);

    // Follow-ups (replace with your real logic)
    const { rows: [{ todays_followups }] } = await cx.query(`
      select 0::int as todays_followups
    `);

    await cx.query("COMMIT");

    return res.json({
      open_leads_count,
      todays_followups,
      open_leads_trend: "+14%", // or compute
    });
  } catch (err) {
    try { await cx.query("ROLLBACK"); } catch {}
    next(err);
  } finally {
    cx.release();
  }
});

export default router;
