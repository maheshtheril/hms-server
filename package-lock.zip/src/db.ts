// server/src/db.ts
import "dotenv/config";

import { Pool, PoolClient, QueryResult } from "pg";  // ← named import

const connectionString =
  process.env.DATABASE_URL ||
  "postgresql://mahdbuser:R2oCeaIrcbyFDW9gpI3hcGIbYADDVrvX@dpg-d2trq56r433s73dml4e0-a.singapore-postgres.render.com/mahdb";

const useSSL =
  !connectionString.includes("localhost") &&
  !connectionString.includes("127.0.0.1");

export const pool = new Pool({
  connectionString,
  ssl: useSSL ? { rejectUnauthorized: false } : undefined,
});

export async function query<T = any>(text: string, params?: any[]): Promise<QueryResult<T>> {
  return pool.query<T>(text, params);
}
export async function q(sql: string, params: any[] = []) { return query(sql, params); }

export type { PoolClient, QueryResult };
export default { query, q, pool };
